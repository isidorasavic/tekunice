package com.sbnz.tekunicebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TekuniceBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
