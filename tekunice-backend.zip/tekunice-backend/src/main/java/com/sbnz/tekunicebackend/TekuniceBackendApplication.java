package com.sbnz.tekunicebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TekuniceBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TekuniceBackendApplication.class, args);
	}

}
