package com.sbnz.tekunice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TekuniceApplicationTests {

	@Test
	void contextLoads() {
	}

}
