package com.sbnz.tekunice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TekuniceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TekuniceApplication.class, args);
	}

}
